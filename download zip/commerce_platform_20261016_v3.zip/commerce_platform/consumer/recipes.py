"""Source-supplied recipe workflow. No invented recipe corpus or automatic shopping."""
from pydantic import BaseModel, Field
from shared.recipe_contracts import RecipeEvidence, shortage

class Ingredient(BaseModel):
    name: str
    required: bool = True
    quantity: float | None = Field(None, ge=0)
    unit: str | None = None
    cooking_state: str | None = None
    owned: float | None = Field(None, ge=0)
    owned_unit: str | None = None
    owned_state: str | None = None
    evidence: RecipeEvidence

class RecipePlan(BaseModel):
    title: str
    ingredients: list[Ingredient] = Field(default_factory=list, max_length=100)

    def evaluate(self):
        rows = []
        for i in self.ingredients:
            if i.quantity is None or i.owned is None:
                result = {"shortage": None, "shopping_dispatch": False,
                          "question": "원문 필요량과 보유량을 확인해 주세요."}
            else:
                result = shortage(i.quantity, i.owned, i.unit, i.owned_unit, i.cooking_state, i.owned_state)
            rows.append({"name": i.name, "required": i.required, **result,
                         "evidence": i.evidence.quantities()})
        return {"title": self.title, "ingredients": rows,
                "missing_required": [r for r in rows if r["required"] and r["shortage"] is not None and r["shortage"] > 0],
                "unresolved": [r["name"] for r in rows if r["shortage"] is None],
                "status": "HUMAN_REVIEW_REQUIRED", "api_calls": 0, "shopping_dispatch": False}
