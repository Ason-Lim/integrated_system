"""Preserve recipe source quantities, never convert body-size descriptions to grams."""
import re
from pydantic import BaseModel, Field

class RecipeEvidence(BaseModel):
    source_id: str
    raw_text: str
    cooking_state: str | None = None
    page: int | None = Field(None, ge=1)
    bbox: tuple[float, float, float, float] | None = None
    status: str = "EXTRACTED_UNVERIFIED"

    def quantities(self):
        return {"raw_text": self.raw_text,
                "explicit_quantities": re.findall(r"\d+(?:\.\d+)?\s*(?:kg|g|ml|mL|L)(?![A-Za-z])", self.raw_text),
                "cooking_state": self.cooking_state,
                "new_conversions": None, "source_id": self.source_id,
                "requires_review": True}

def shortage(required, owned, required_unit, owned_unit, required_state, owned_state):
    if required < 0 or owned < 0:
        raise ValueError("quantity must be nonnegative")
    if required_unit != owned_unit or not required_state or required_state != owned_state:
        return {"shortage": None, "shopping_dispatch": False,
                "question": "단위와 마른 재료·조리된 재료 여부를 확인해 주세요."}
    return {"shortage": max(0, required-owned), "shopping_dispatch": False}
